﻿;if(!dbank) var dbank =  {};
if(!dbank.login) dbank.login = {};

(function(){
	dbank.login.tmpldata = {
	        tip                 :      '',
			usernameTip         :      '',
			passwordTip         :      '',
			loginButton         :      '登录',
			autologinTip        :      '记住登录',
			forgetPasswordTip   :      '忘记密码？',
			otherLoginTypeTip   :      '其他方式登录',
			qqLoginTip          :      '',
			sinaLoginTip        :      '',
			qqLoginTitle        :      'QQ帐号登录',
			sinaLoginTitle      :      '微博帐号登录'
	}
})();